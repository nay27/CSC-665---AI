# multiAgents.py
# --------------
# Licensing Information:  You are free to use or extend these projects for
# educational purposes provided that (1) you do not distribute or publish
# solutions, (2) you retain this notice, and (3) you provide clear
# attribution to UC Berkeley, including a link to http://ai.berkeley.edu.
# 
# Attribution Information: The Pacman AI projects were developed at UC Berkeley.
# The core projects and autograders were primarily created by John DeNero
# (denero@cs.berkeley.edu) and Dan Klein (klein@cs.berkeley.edu).
# Student side autograding was added by Brad Miller, Nick Hay, and
# Pieter Abbeel (pabbeel@cs.berkeley.edu).


from util import manhattanDistance
from game import Directions
import random, util

from game import Agent

class ReflexAgent(Agent):
    """
      A reflex agent chooses an action at each choice point by examining
      its alternatives via a state evaluation function.

      The code below is provided as a guide.  You are welcome to change
      it in any way you see fit, so long as you don't touch our method
      headers.
    """


    def getAction(self, gameState):
        """
        You do not need to change this method, but you're welcome to.

        getAction chooses among the best options according to the evaluation function.

        Just like in the previous project, getAction takes a GameState and returns
        some Directions.X for some X in the set {North, South, West, East, Stop}
        """
        # Collect legal moves and successor states
        legalMoves = gameState.getLegalActions()
      
        # Choose one of the best actions
        scores = [self.evaluationFunction(gameState, action) for action in legalMoves]
        bestScore = max(scores)
        bestIndices = [index for index in range(len(scores)) if scores[index] == bestScore]
        chosenIndex = random.choice(bestIndices) # Pick randomly among the best

        "Add more of your code here if you want to"

        return legalMoves[chosenIndex]

    def evaluationFunction(self, currentGameState, action):
        """
        Design a better evaluation function here.

        The evaluation function takes in the current and proposed successor
        GameStates (pacman.py) and returns a number, where higher numbers are better.

        The code below extracts some useful information from the state, like the
        remaining food (newFood) and Pacman position after moving (newPos).
        newScaredTimes holds the number of moves that each ghost will remain
        scared because of Pacman having eaten a power pellet.

        Print out these variables to see what you're getting, then combine them
        to create a masterful evaluation function.
        """
        # Useful information you can extract from a GameState (pacman.py)
        successorGameState = currentGameState.generatePacmanSuccessor(action)
        newPos = successorGameState.getPacmanPosition()
        newFood = successorGameState.getFood()
        newGhostStates = successorGameState.getGhostStates()
        newScaredTimes = [ghostState.scaredTimer for ghostState in newGhostStates]

        "*** YOUR CODE HERE ***"
        """print("successorGameState: ", successorGameState)
        print("newPos: ", newPos )
        print("newFood: ", newFood.asList() )
        print("newGhostStates: ", newGhostStates)
        print ("newScaredTimes: ", newScaredTimes)"""
        
        #get score and set as value
        value = successorGameState.getScore()


        #list of distance from  pacman to ghost
        distancesToGhost = []

        minGhostDist = float('inf') 
        #iterate thru the ghosts using newGhostStates
        for ghosts in newGhostStates:
          #use manhattanDistance to calculate distance using ghosts position and pacman position
          #append them to the list distanceToGhost
          distancesToGhost.append(manhattanDistance(newPos, ghosts.getPosition()))

        #get minGhostDist using min of list distanceToGhost
        minGhostDist = min(distancesToGhost)

        #only account in ghosts if there are any on the map
        if minGhostDist> 0:
            value -= 2.0 / minGhostDist

        #list of distance from pacman to foods on the map
        distancesToFood = []

        #iterate thru the foods on the map using newFood list (successorGameState.getFood())
        for food in newFood.asList():
          #use manhattanDistance to calculate distance between the current food position and pacman position
          #append them to the list distancesToFood
          distancesToFood.append(manhattanDistance(newPos, food))


        #init minFoodDist to inf 
        minFoodDist = float('inf') 

        #check if len is true for distancesToFood
        #as long as there are food on the map, this len should be true
        if len(distancesToFood):
          #set minFoodDist to min of distancesToFood lisr
          minFoodDist = min(distancesToFood)

        #only account if minFoodDist >0
        if minFoodDist > 0:
            value += 1.0 / minFoodDist

        return value  


def scoreEvaluationFunction(currentGameState):
    """
      This default evaluation function just returns the score of the state.
      The score is the same one displayed in the Pacman GUI.

      This evaluation function is meant for use with adversarial search agents
      (not reflex agents).
    """
    return currentGameState.getScore()

class MultiAgentSearchAgent(Agent):
    """
      This class provides some common elements to all of your
      multi-agent searchers.  Any methods defined here will be available
      to the MinimaxPacmanAgent, AlphaBetaPacmanAgent & ExpectimaxPacmanAgent.

      You *do not* need to make any changes here, but you can if you want to
      add functionality to all your adversarial search agents.  Please do not
      remove anything, however.

      Note: this is an abstract class: one that should not be instantiated.  It's
      only partially specified, and designed to be extended.  Agent (game.py)
      is another abstract class.
    """

    def __init__(self, evalFn = 'scoreEvaluationFunction', depth = '2'):
        self.index = 0 # Pacman is always agent index 0
        self.evaluationFunction = util.lookup(evalFn, globals())
        self.depth = int(depth)

class MinimaxAgent(MultiAgentSearchAgent):
    """
      Your minimax agent (question 2)
    """

    def getAction(self, gameState):
        """
          Returns the minimax action from the current gameState using self.depth
          and self.evaluationFunction.

          Here are some method calls that might be useful when implementing minimax.

          gameState.getLegalActions(agentIndex):
            Returns a list of legal actions for an agent
            agentIndex=0 means Pacman, ghosts are >= 1

          gameState.generateSuccessor(agentIndex, action):
            Returns the successor game state after an agent takes an action

          gameState.getNumAgents():
            Returns the total number of agents in the game
        """
        "*** YOUR CODE HERE ***"
        self.countAgents = gameState.getNumAgents()
        result =self.MaxValue(gameState, 0,0)
        return result[1]  

    #getValue function get the score of the currentstate
    #if it is a base case, will use evaluation function to return score
    #if it is a min or max node, they will call maxValue function or MinValue function to get the score
    def getValue(self,gameState, depthIndex, agentIndex):
        
        #get total number of layer for the search tree
        totalSearch = self.countAgents * self.depth
        """print ("totalSearch test: ", totalSearch)"""

        #base case for recusion, return value if its a leave node 
        if depthIndex>=totalSearch or gameState.isWin() or gameState.isLose():
            return self.evaluationFunction(gameState)
        #if its pacman get maxvalue from previous nodes, else get minvalue 
        if agentIndex == 0:   
            #index 0 of the return function is the score, [1] is the action
            return self.MaxValue(gameState, depthIndex, agentIndex)[0] 
        else:
            return self.MinValue(gameState, depthIndex, agentIndex)
            
    
    #MaxValue function return the max Score from the successor states
    #call get value to recurse through the agents for given depth
    #return score and action since it is for pacman
    def MaxValue(self,gameState, depthIndex, agentIndex):  
        #inti numAgents
        numAgents = self.countAgents
        #get actions for current agent
        legalActions=gameState.getLegalActions(agentIndex)
        #init to -inf to search for max value
        maxValue = -float('inf')
        #init action to none
        returnedAction = None
        for action in legalActions:
            #get successor states using legal actions of the current agent
            successorState = gameState.generateSuccessor(agentIndex, action)
            #increment to next layer of search 
            nextDepth = depthIndex + 1
            """get value using getValue function, use % to iterate through agents using depthIndex to make sure the nextdepht correspond 
            to the next agentIndex
            i.e starts with depth of 0 for pacman. nextdepht should be for the first ghost, agent[1]. 1 % 3 = 1. nextDepht then increment 
            to 2 on the next iteration for 2nd ghost. 2 % 3 = 2 which is the agentIdex for the 2nd ghost. Next depht should be for pacman, 3 % 3 = 0"""
            value = self.getValue(successorState, nextDepth, nextDepth % numAgents)
            #compare value with maxValue to set maxValue
            if value > maxValue:
                maxValue = value
                returnedAction = action
        return [maxValue, returnedAction]   
        
    #MinValue function get the min score from the successor states of its current state
    #return just the score since we do not need the action of the ghosts
    #same implementation as MaxValue but for min instead
    def MinValue(self,gameState, depthIndex, agentIndex):  
        #init numAgents
        numAgents = self.countAgents
        #get actions for current agent
        legalActions=gameState.getLegalActions(agentIndex)
        #init to inf to search for min value
        minValue=float("inf")
        for action in legalActions:
            successorState = gameState.generateSuccessor(agentIndex, action)
            nextDepth = depthIndex + 1
            value = self.getValue(successorState, nextDepth, nextDepth % numAgents)
            if value < minValue:
                minValue = value

        return minValue


class AlphaBetaAgent(MultiAgentSearchAgent):
    """
      Your minimax agent with alpha-beta pruning (question 3)
    """

    def getAction(self, gameState):
        """
          Returns the minimax action using self.depth and self.evaluationFunction
        """
        "*** YOUR CODE HERE ***"

        """alphabeta is the same implementation as minimax, execpt we add 2 more perameters; alpha and beta.
        followed the implementation of alpha beta pruning from slides."""

        #init alpha and beta to -inf and inf
        alpha = -float('inf')
        beta = float('inf')
        self.countAgents = gameState.getNumAgents()
        result =self.MaxValue(gameState, 0,0, alpha, beta)
        return result[1]  
        

    def getValue(self,gameState, depthIndex, agentIndex, alpha, beta):
        
        #get total number of layer for the search tree
        totalSearch = self.countAgents * self.depth
        #base case for recusion, return value if its a leave node 
        if depthIndex>=totalSearch or gameState.isWin() or gameState.isLose():
            return self.evaluationFunction(gameState)
        #if its pacman get maxvalue from previous nodes, else get minvalue 
        if agentIndex == 0:   
            return self.MaxValue(gameState, depthIndex, agentIndex, alpha, beta)[0]   
        else:
            return self.MinValue(gameState, depthIndex, agentIndex, alpha, beta)

    def MaxValue(self,gameState, depthIndex, agentIndex, alpha, beta):  
        #inti numAgents
        numAgents = self.countAgents
        #get actions for current agent
        legalActions=gameState.getLegalActions(agentIndex)
        #init to -inf to search for max value
        maxValue = -float('inf')
        #init action to non
        returnedAction = None
        for action in legalActions:
            #get successor states using legal actions of the current agent
            successorState = gameState.generateSuccessor(agentIndex, action)
            #increment to next layer of search 
            nextDepth = depthIndex + 1
            value = self.getValue(successorState, nextDepth, nextDepth % numAgents, alpha, beta)
            #compare value with maxValue to set maxValue
            if value > maxValue:
                maxValue = value
                returnedAction = action
                #compare maxValue with beta. Implement same algorithm as lecture slide
                if maxValue > beta:
                  return [maxValue, returnedAction]
                alpha = max(alpha, maxValue)
        return [maxValue, returnedAction]   
        

    def MinValue(self,gameState, depthIndex, agentIndex, alpha, beta):  
        #init numAgents
        numAgents = self.countAgents
        #get actions for current agent
        legalActions=gameState.getLegalActions(agentIndex)
        #init to inf to search for min value
        minValue=float("inf")
        #init action to none 
        returnedAction = None
        for action in legalActions:
            successorState = gameState.generateSuccessor(agentIndex, action)
            nextDepth = depthIndex + 1
            value = self.getValue(successorState, nextDepth, nextDepth % numAgents, alpha, beta)
            if value < minValue:
                minValue = value
                returnedAction = action
                #compare minValue with alpha. Implement same algorithm as lecture slide
                if minValue < alpha:
                  return minValue
                beta = min(beta, minValue)
        return minValue
    


      

class ExpectimaxAgent(MultiAgentSearchAgent):
    """
      Your expectimax agent (question 4)
    """

    def getAction(self, gameState):
        """
          Returns the expectimax action using self.depth and self.evaluationFunction

          All ghosts should be modeled as choosing uniformly at random from their
          legal moves.
        """
        "*** YOUR CODE HERE ***"  

        """Expectimax use the same implementation as minimax, except instead of min, we are calulating the expected value
        used the algorithem in slides to implement this"""

        self.countAgents = gameState.getNumAgents()
        pacmanAction=self.MaxValue(gameState, 0,0)
        return pacmanAction[1]  

    def getValue(self,gameState, depthIndex, agentIndex):
        
        #get total number of layer for the search tree
        totalSearch = self.countAgents * self.depth
        #base case for recusion, return value if its a leave node 
        if depthIndex>=totalSearch or gameState.isWin() or gameState.isLose():
            return self.evaluationFunction(gameState)
        #if its pacman get maxvalue from previous nodes, else get expectedvalue from the ghosts 
        if agentIndex == 0:   
            return self.MaxValue(gameState, depthIndex, agentIndex)[0]   
        else:
            return self.ExpValue(gameState, depthIndex, agentIndex)
    
    def MaxValue(self,gameState, depthIndex, agentIndex):  
        #inti numAgents
        numAgents = self.countAgents
        #get actions for current agent
        legalActions=gameState.getLegalActions(agentIndex)
        #init to -inf to search for max value
        maxValue = -float('inf')
        #init action to non
        returnedAction = None
        for action in legalActions:
            #get successor states using legal actions of the current agent
            successorState = gameState.generateSuccessor(agentIndex, action)
            #increment to next layer of search 
            nextDepth = depthIndex + 1
            value = self.getValue(successorState, nextDepth, nextDepth % numAgents)
            #compare value with maxValue to set maxValue
            if value > maxValue:
                maxValue = value
                returnedAction = action
        return [maxValue, returnedAction]   
        
  
    def ExpValue(self,gameState, depthIndex, agentIndex):  
        #init numAgents
        numAgents = self.countAgents
        #get actions for current agent
        legalActions=gameState.getLegalActions(agentIndex)
        #expectedValueList init
        expectedValuesList = []
        for action in legalActions:
            successorState = gameState.generateSuccessor(agentIndex, action)
            nextDepth = depthIndex + 1
            value = self.getValue(successorState, nextDepth, nextDepth % numAgents)
            #append the values to the list expectedValueList
            expectedValuesList.append(value)
        #calc. the value using the expectedValueList sum and prob. of the actions (1/num of actions) 
        #Implement same algorithm as lecture slide
        expectedValue = sum(expectedValuesList)*1.0/len(legalActions)

        return expectedValue
        

def betterEvaluationFunction(currentGameState):
    """
      Your extreme ghost-hunting, pellet-nabbing, food-gobbling, unstoppable
      evaluation function (question 5).

      DESCRIPTION: <write something here so we know what you did>

      used the same logic as reflex but accounted the scared timer. Refer to the ReadMe
    """
    "*** YOUR CODE HERE ***"
    
    #get pacman position
    newPos = currentGameState.getPacmanPosition()

    #use score as value
    value = scoreEvaluationFunction(currentGameState)

    #list of food and ghost
    distancesToFood = []
    distancesToGhost = []

    #values to calculate to add/subtract to value
    scaredValue = 0.0
    foodValue = 0.0
    ghostValue = 0.0
    minGhostDist = float('inf')
    
    # calculate foodValue using foodstate
    newFood = currentGameState.getFood()
    for food in newFood.asList():
        #use manhattanDistance ulti func. with newPos and food to calculate distance
        distancesToFood.append(manhattanDistance(newPos, food))
        #use inverse of the min of distancesToFood as advised in the assignment
        foodValue = 1.0/min(distancesToFood)
         #print ("foodValue: " ,foodValue)

    # calculate ghostValue
    newGhostStates = currentGameState.getGhostStates()
    for ghosts in newGhostStates:
        #if ghost not scare, will add value, 
        if ghosts.scaredTimer == 0:
            scaredValue += 1
        #same as food, use manhattanDistance to calculate distance of Ghost
        distancesToGhost.append(manhattanDistance(newPos, ghosts.getPosition()))
        #get min dist of distancesToGhost
        minGhostDist = min(distancesToGhost)
        # print("minGhostDist: " , minGhostDist)

    #check to make sure we dont divide by 0.
    if minGhostDist > 0:
        #use inverse as advised 
        ghostValue= 2.0 / minGhostDist


    #add foodValue and subtract the negative effects, ghostValue and scaredValue
    value = value + foodValue - ghostValue - scaredValue
    
    return value 



# Abbreviation
better = betterEvaluationFunction

