
Naylin Min
917101684

Partner:
Shan Kwan Cho
917599337

Description:

For question 1, we get actual and predict values from the trainingLabels and trainingData. If they are not equal, we update the weights according to the instructions. Ie. w(new) = w(old) +/- featureVector

For question 2, we sorted the weights of the given label and updated the featuresWeight array with the sorted values. Also have to update answers.py to a or b based on the question in the reader. 

For question 3, first we iterate through the iterations. For each iterations, we iterate through the training data. For each legal labels in the current image of the training data, we get prediction value by multiplying the currentData with the weight of the label. We then update the bestScore if prediction is > than bestScore. If the label for the bestScore does not equal actual label, we update the weights by multiplying t value to the feature vector. Much like question 1, however, we use the given formula in the instruction for the t value.  

For question 4, we tested the pixels of the image to see if they are in bound and updated the feature vector accordingly. We also tested for neighbors of the pixels. If the pixels have more than 2 neighbors, we updated the feature vector. However, was only able to score 3 out of 6 on this one. Was not able to further improve on it. 

For question 5, this question is very similar to the question 1 , within two different types of classifiers, just need to update the weight after each iteration using w(new) = w(old) +/- feature vectors, correct and guessed action respectively. Of each training, getting highest scores ( arg max scores ) of label, take those and update each. Training accuracy got above 70 prediction.  

For question 6, as stated in the hints, we use the format <feature name> : <feature value> for the feature vector. We first get successor of the state and get a list of food for that successor state. Then, we iterate through the food and convert the coordinates of the food to a string and store that for <feature name> and calculate the inverse of ManhattanDistance and set that as <feature value>.

The Total time I spent for this project is more than 4 days. Took a while for us to understand the functions used as well as the overall structure of the code. Some of the topics, such as enhancing the feature vector, are a bit confusion on how they work. 